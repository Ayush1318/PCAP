
from PySide6.QtWidgets import QApplication, QMainWindow, QLabel
import sys

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("NOC Analyzer")
        self.setCentralWidget(QLabel("NOC Analyzer Starter Project"))

app = QApplication(sys.argv)
w = MainWindow()
w.show()
sys.exit(app.exec())
