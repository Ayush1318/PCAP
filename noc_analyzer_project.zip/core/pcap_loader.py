
import pyshark

def load_pcap(path):
    return pyshark.FileCapture(path)
