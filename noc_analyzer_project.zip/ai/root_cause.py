
def analyze(summary):
    return f'Root cause analysis placeholder: {summary}'
